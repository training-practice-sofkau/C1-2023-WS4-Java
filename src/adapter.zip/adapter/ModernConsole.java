package adapter;

import adapter.controllers.ModernControl;
import adapter.controllers.OldControl;

public class ModernConsole {

    public void play (ModernControl modernCont){
        System.out.println("Now you can play");
    }
}

package adapter;

import adapter.controllers.OldControl;

public interface Controllable {
    public void readController(OldControl oldControl);
}

package adapter.controllers;

public class OldControl {
    private Integer button;

    public OldControl(Integer button) {
        this.button = button;
    }

    public Integer getButton() {
        return button;
    }

    public void setButton(Integer button) {
        this.button = button;
    }
}

package adapter.controllers;

public class ModernControl {
    private Integer button;

    public ModernControl(Integer button) {
        this.button = button;
    }

    public Integer getButton() {
        return button;
    }

    public void setButton(Integer button) {
        this.button = button;
    }
}
